import rclpy
import cv2
import numpy as np
from cv_bridge import CvBridge
from sensor_msgs.msg import Image
from rclpy.node import Node
from std_msgs.msg import String
from geometry_msgs.msg import Twist

# Definición de la clase 
class LineFollower(Node):
    # Constructor 
    def __init__(self):
        # Definición del tópico
        super().__init__('Azul_LineFollower_node')

        # Variables para la camara
        self.valid_img = False
        self.bridge = CvBridge()
        self.sub = self.create_subscription(Image, '/video_source/raw', self.camera_callback, rclpy.qos.qos_profile_sensor_data)

        #Creación del tópico publicador: cmd_vel
        self.publisher2 = self.create_publisher(Twist, 'cmd_vel', 10)

        # Timer period
        timer_period = 0.05
        self.timer = self.create_timer(timer_period, self.timer_callback)

        #Print info to confirm node was made.
        self.get_logger().info('Line Follower node successfully initialized!!!')

    def resize_image(self, img):
        # Crop the image
        height, width = img.shape[:2]
        start_y = int(height * 0.55)  # Adjusted to crop an additional 15% from the top
        end_y = height  # Keep the bottom part of the image
        start_x = 2 * width // 8
        end_x = 6 * width // 8
        
        cropped_img = img[start_y:end_y, start_x:end_x]
        return cropped_img

    def timer_callback(self):
        try:
            if self.valid_img:
                # Inicializamos a 0.0 las variables que no utilizaremos del Twist y mandaremos a cmd_vel
                cmd_vel = Twist()
                cmd_vel.linear.y = 0.0
                cmd_vel.linear.x = 0.0
                cmd_vel.linear.z = 0.0
                cmd_vel.angular.x = 0.0
                cmd_vel.angular.y = 0.0

                frame = cv2.cvtColor(self.img, cv2.COLOR_BGR2HSV)

                # Rotate the frame 180 degrees
                frame = cv2.rotate(frame, cv2.ROTATE_180)

                # Resize and crop the frame
                resized_frame = self.resize_image(frame)

                filtro_median = cv2.medianBlur(resized_frame, 3)

                # Convert the extracted portion to grayscale
                gray_image = cv2.cvtColor(filtro_median, cv2.COLOR_BGR2GRAY)

                # Binarize the grayscale image using Otsu's method
                _, binary_image = cv2.threshold(gray_image, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)

                # Apply morphological operations
                SE_d = np.ones((10, 10), np.uint8)
                morf_d = cv2.dilate(binary_image, SE_d, iterations=5)
                SE_e = np.ones((10, 10), np.uint8)
                morf_e = cv2.erode(morf_d, SE_e, iterations=1)
                imagenProcesada = cv2.bitwise_not(morf_e)

                #Conteo de pixeles
                centro_img_x = int(morf_e.shape[1]/2)
                centro_img_y = 10
                dimy = int(morf_e.shape[0]/2)

                cont = 0
                bandera =centroide_primer_punto_x = 0
                centroide_primer_punto_y = 0
                for i in range (morf_e.shape[1]):
                    if morf_e[dimy][i] == 0:
                        cont += 1
                    if (bandera == 0 and morf_e[dimy][i] == 0):
                        centroide_primer_punto_x = i
                        centroide_primer_punto_y = dimy
                        bandera = 1
                error = ((centroide_primer_punto_x + cont/2)-centro_img_x )/(morf_e.shape[1])

                # Get the width of the resized frame for direction calculation
                #height, width = resized_frame.shape[:2]
                #center_x = width // 2
                #margin = 80  # Define a small margin around the center line

                # Default direction
                direction = ''

                # Calculate deviation from center in X-axis
                #deviation_x = (cX - center_x) / 450

                # Determine the direction to turn
                if error != 0:
                    if error >= -0.05 and error <= 0.05:
                        direction = 'F'
                        cmd_vel.angular.z = 0.0
                        cmd_vel.linear.x = 0.05
                    elif error <= -0.05:
                        direction = 'L'
                        cmd_vel.angular.z = (0.15 * error)
                        cmd_vel.linear.x = 0.05
                        if cmd_vel.angular.z < 0.05:
                            cmd_vel.angular.z = 0.05
                    elif error >= 0.05:
                        direction = 'R'
                        cmd_vel.angular.z = (0.15 * error)
                        cmd_vel.linear.x = 0.05
                        if cmd_vel.angular.z > -0.05:
                            cmd_vel.angular.z = -0.05
                    else:
                        direction = 'F'
                        cmd_vel.angular.z = 0.0
                        cmd_vel.linear.x = 0.05

                # Create a String message and publish the direction
                self.get_logger().info(f"Deviation X: {error}, Direction: {direction}")

                self.publisher2.publish(cmd_vel)

        except Exception as e:
            self.get_logger().error(f'Failed to process image: {str(e)}')

    def camera_callback(self, msg):
        try:
            self.img = self.bridge.imgmsg_to_cv2(msg, "bgr8")
            self.valid_img = True
        except Exception as e:
            self.get_logger().error(f'Failed to get an image: {str(e)}')

# Main function
def main(args=None):
    # Initialization for rclpy 
    rclpy.init(args=args)
    # Create node
    m_p = LineFollower()
    # Spin method for publisher callback
    rclpy.spin(m_p)
    # Destroy node
    m_p.destroy_node()
    # rclpy shutdown
    rclpy.shutdown()

# Main call method
if __name__ == '__main__':    
    main()
